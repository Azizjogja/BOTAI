const axios = require('axios')

const pluginConfig = {
    name: 'gemma2b',
    alias: ['gamma2b', 'gemma2'],
    category: 'ai',
    description: 'Chat dengan Gemma 2B',
    usage: '.gemma2b <pertanyaan>',
    example: '.gemma2b Hai apa kabar?',
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 5,
    limit: 1,
    isEnabled: true
}

async function handler(m, { sock }) {
    const text = m.args.join(' ')
    if (!text) {
        return m.reply(`💎 *ɢᴇᴍᴍᴀ 2ʙ*\n\n> Masukkan pertanyaan\n\n\`Contoh: ${m.prefix}gemma2b Hai apa kabar?\``)
    }
    
    m.react('💎')
    
    try {
        const url = `https://api.nekolabs.web.id/txt.gen/cf/gemma-2b-lora?text=${encodeURIComponent(text)}`
        const { data } = await axios.get(url, { timeout: 60000 })
        
        if (!data?.success || !data?.result) {
            m.react('❌')
            return m.reply(`❌ *ɢᴀɢᴀʟ*\n\n> API tidak merespon`)
        }
        
        m.react('✅')
        await m.reply(`💎 *ɢᴇᴍᴍᴀ 2ʙ*\n\n${data.result}`)
        
    } catch (error) {
        m.react('❌')
        m.reply(`❌ *ᴇʀʀᴏʀ*\n\n> ${error.message}`)
    }
}

module.exports = {
    config: pluginConfig,
    handler
}
