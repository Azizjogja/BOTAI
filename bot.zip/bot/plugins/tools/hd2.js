const axios = require('axios')
const FormData = require('form-data')

const pluginConfig = {
    name: 'hd2',
    alias: ['enhance2', 'upscale2', 'supawork'],
    category: 'tools',
    description: 'Enhance gambar menjadi HD dengan SupaWork AI',
    usage: '.hd2 (reply gambar)',
    example: '.hd2',
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 15,
    limit: 1,
    isEnabled: true
}

async function uploadToCatbox(buffer) {
    const form = new FormData()
    form.append('reqtype', 'fileupload')
    form.append('fileToUpload', buffer, { filename: 'image.jpg', contentType: 'image/jpeg' })
    
    const response = await axios.post('https://catbox.moe/user/api.php', form, {
        headers: form.getHeaders(),
        timeout: 60000
    })
    
    return response.data
}

async function handler(m, { sock }) {
    const isImage = m.isImage || (m.quoted && m.quoted.type === 'imageMessage')
    
    if (!isImage) {
        return m.reply(`✨ *ʜᴅ ᴇɴʜᴀɴᴄᴇ ᴠ2*\n\n> Kirim/reply gambar untuk di-enhance\n\n\`${m.prefix}hd2\``)
    }
    
    m.react('⏳')
    
    try {
        let buffer
        if (m.quoted && m.quoted.isMedia) {
            buffer = await m.quoted.download()
        } else if (m.isMedia) {
            buffer = await m.download()
        }
        
        if (!buffer) {
            m.react('❌')
            return m.reply(`❌ Gagal mendownload gambar`)
        }
        
        await m.reply(`⏳ *ᴍᴇɴɢᴜᴘʟᴏᴀᴅ ɢᴀᴍʙᴀʀ...*`)
        
        const imageUrl = await uploadToCatbox(buffer)
        
        if (!imageUrl || !imageUrl.startsWith('http')) {
            m.react('❌')
            return m.reply(`❌ Gagal upload gambar ke Catbox`)
        }
        
        await m.reply(`⏳ *ᴍᴇᴍᴘʀᴏsᴇs ᴅᴇɴɢᴀɴ sᴜᴘᴀᴡᴏʀᴋ ᴀɪ...*\n\n> Proses ini mungkin memakan waktu 30-60 detik`)
        
        const apiUrl = `https://api.nekolabs.web.id/tools/upscale/supawork?imageUrl=${encodeURIComponent(imageUrl)}&scale=1`
        
        const res = await axios.get(apiUrl, { timeout: 120000 })
        
        if (!res.data?.success || !res.data?.result) {
            m.react('❌')
            return m.reply(`❌ Gagal enhance gambar\n\n> ${res.data?.message || 'Unknown error'}`)
        }
        
        m.react('✅')
        
        await sock.sendMessage(m.chat, {
            image: { url: res.data.result },
            caption: `✨ *ʜᴅ ᴇɴʜᴀɴᴄᴇ ᴠ2*\n\n> Powered by SupaWork AI\n> Response time: \`${res.data.responseTime || 'N/A'}\``
        }, { quoted: m })
        
    } catch (error) {
        m.react('❌')
        m.reply(`❌ *ᴇʀʀᴏʀ*\n\n> ${error.message}`)
    }
}

module.exports = {
    config: pluginConfig,
    handler
}
