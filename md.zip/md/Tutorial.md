#CARA DAPATKAN APIKEYS/VERIFIKASI AKUN CIA TOPUP
1. buka dan daftar/login ciatopup "https://www.ciaatopup.my.id/"
2. pencet gambar orang di kanan atas, lalu pencet "support", lalu pilih *WhatsApp"
3. untuk verifikasi akun ciatopup kamu bisa mengirim chat ini

#TEKS NYA 
`Hai kak, Saya Dari Pengguna script Lyrra ingin memverifikasi akun ciaatopup saya
User name: Name
Kode Referral: RIZKY20092948
`