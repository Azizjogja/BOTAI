const {
  Client
} = require('ssh2')

let handler = async (m, {
  sock,
  prefix,
  text,
  isOwner
}) => {
  if (!isOwner) return m.reply('Khusus Owner')
  if (!text) return m.reply("ipvps|pwvps|panel.com|node.com|ram_server|nama_node *(contoh 100000)*")
  let vii = text.split("|")
  if (vii.length < 6) return m.reply("ipvps|pwvps|panel.com|node.com|ramserver *(contoh 100000)*")
  let sukses = false

  const ress = new Client();
  const connSettings = {
    host: vii[0],
    port: '22',
    username: 'root',
    password: vii[1]
  }

  const pass = randomKarakter(7)
  const passwordPanel = pass
  const domainpanel = vii[2]
  const domainnode = vii[3]
  const ramserver = vii[4]
  const namenode = vii[5]
  const deletemysql = `\n`
  const commandPanel = `bash <(curl -s https://pterodactyl-installer.se)`

  async function instalWings() {
    ress.exec(commandPanel, (err, stream) => {
      if (err) throw err;
      stream.on('close', async (code, signal) => {
        ress.exec('bash <(curl -s https://raw.githubusercontent.com/veryLinh/Theme-Autoinstaller/main/createnode.sh)', async (err, stream) => {
          if (err) throw err;
          stream.on('close', async (code, signal) => {
            let teks = `
*📦 Berikut Detail Akun Panel :*

* *Username :* admin
* *Password :* ${passwordPanel}
* *Domain :* ${domainpanel}

*Note :* Silahkan Buat Allocation & Ambil Token Wings Di Node Yang Sudah Di Buat Oleh Bot Untuk Menjalankan Wings

*Cara Menjalankan Wings :*
ketik *${prefix}startwings* ipvps|pwvps|tokenwings
`
            await sock.sendMessage(m.chat, {
              text: teks
            }, {
              quoted: m
            })
          }).on('data', async (data) => {
            await console.log(data.toString())
            if (data.toString().includes("Masukkan nama lokasi: ")) {
              stream.write('Singapore\n');
            }
            if (data.toString().includes("Masukkan deskripsi lokasi: ")) {
              stream.write('NODES\n');
            }
            if (data.toString().includes("Masukkan domain: ")) {
              stream.write(`${domainnode}\n`);
            }
            if (data.toString().includes("Masukkan nama node: ")) {
              stream.write(`${namenode}\n`);
            }
            if (data.toString().includes("Masukkan RAM (dalam MB): ")) {
              stream.write(`${ramserver}\n`);
            }
            if (data.toString().includes("Masukkan jumlah maksimum disk space (dalam MB): ")) {
              stream.write(`${ramserver}\n`);
            }
            if (data.toString().includes("Masukkan Locid: ")) {
              stream.write('1\n');
            }
          }).stderr.on('data', async (data) => {
            console.log('Stderr : ' + data);
          });
        });
      }).on('data', async (data) => {
        if (data.toString().includes('Input 0-6')) {
          stream.write('1\n');
        }
        if (data.toString().includes('(y/N)')) {
          stream.write('y\n');
        }
        if (data.toString().includes('Enter the panel address (blank for any address)')) {
          stream.write(`${domainpanel}\n`);
        }
        if (data.toString().includes('Database host username (pterodactyluser)')) {
          stream.write('admin\n');
        }
        if (data.toString().includes('Database host password')) {
          stream.write(`admin\n`);
        }
        if (data.toString().includes('Set the FQDN to use for Let\'s Encrypt (node.example.com)')) {
          stream.write(`${domainnode}\n`);
        }
        if (data.toString().includes('Enter email address for Let\'s Encrypt')) {
          stream.write('admin@gmail.com\n');
        }
        console.log('Logger: ' + data.toString())
      }).stderr.on('data', (data) => {
        console.log('STDERR: ' + data);
      });
    })
  }

  async function instalPanel() {
    ress.exec(commandPanel, (err, stream) => {
      if (err) throw err;
      stream.on('close', async (code, signal) => {
        await instalWings()
      }).on('data', async (data) => {
        if (data.toString().includes('Input 0-6')) {
          stream.write('0\n');
        }
        if (data.toString().includes('(y/N)')) {
          stream.write('y\n');
        }
        if (data.toString().includes('Database name (panel)')) {
          stream.write('\n');
        }
        if (data.toString().includes('Database username (pterodactyl)')) {
          stream.write('admin\n');
        }
        if (data.toString().includes('Password (press enter to use randomly generated password)')) {
          stream.write('admin\n');
        }
        if (data.toString().includes('Select timezone [Europe/Stockholm]')) {
          stream.write('Asia/Jakarta\n');
        }
        if (data.toString().includes('Provide the email address that will be used to configure Let\'s Encrypt and Pterodactyl')) {
          stream.write('admin@gmail.com\n');
        }
        if (data.toString().includes('Email address for the initial admin account')) {
          stream.write('admin@gmail.com\n');
        }
        if (data.toString().includes('Username for the initial admin account')) {
          stream.write('admin\n');
        }
        if (data.toString().includes('First name for the initial admin account')) {
          stream.write('admin\n');
        }
        if (data.toString().includes('Last name for the initial admin account')) {
          stream.write('admin\n');
        }
        if (data.toString().includes('Password for the initial admin account')) {
          stream.write(`${passwordPanel}\n`);
        }
        if (data.toString().includes('Set the FQDN of this panel (panel.example.com)')) {
          stream.write(`${domainpanel}\n`);
        }
        if (data.toString().includes('Do you want to automatically configure UFW (firewall)')) {
          stream.write('y\n')
        }
        if (data.toString().includes('Do you want to automatically configure HTTPS using Let\'s Encrypt? (y/N)')) {
          stream.write('y\n');
        }
        if (data.toString().includes('Select the appropriate number [1-2] then [enter] (press \'c\' to cancel)')) {
          stream.write('1\n');
        }
        if (data.toString().includes('I agree that this HTTPS request is performed (y/N)')) {
          stream.write('y\n');
        }
        if (data.toString().includes('Proceed anyways (your install will be broken if you do not know what you are doing)? (y/N)')) {
          stream.write('y\n');
        }
        if (data.toString().includes('(yes/no)')) {
          stream.write('y\n');
        }
        if (data.toString().includes('Initial configuration completed. Continue with installation? (y/N)')) {
          stream.write('y\n');
        }
        if (data.toString().includes('Still assume SSL? (y/N)')) {
          stream.write('y\n');
        }
        if (data.toString().includes('Please read the Terms of Service')) {
          stream.write('y\n');
        }
        if (data.toString().includes('(A)gree/(C)ancel:')) {
          stream.write('A\n');
        }
        console.log('Logger: ' + data.toString())
      }).stderr.on('data', (data) => {
        console.log('STDERR: ' + data);
      });
    });
  }

  ress.on('ready', async () => {
    await m.reply("Memproses *install* server panel \nTunggu 1-10 menit hingga proses selsai")
    ress.exec(deletemysql, async (err, stream) => {
      if (err) throw err;
      stream.on('close', async (code, signal) => {
        await instalPanel();
      }).on('data', async (data) => {
        await stream.write('\t')
        await stream.write('\n')
        await console.log(data.toString())
      }).stderr.on('data', async (data) => {
        console.log('Stderr : ' + data);
      });
    });
  }).connect(connSettings);
}

handler.help = ["installpanel"]
handler.tags = ["panelinstall"]
handler.command = ["installpanel", "panelinstall", "installerpanel", "panelinstaller"]

module.exports = handler

function randomKarakter(jumlah) {
  const huruf = 'abcdefghijklmnopqrstuvwxyz'
  let hasil = ''
  for (let i = 0; i < jumlah; i++) {
    const indexAcak = Math.floor(Math.random() * huruf.length);
    let hurufAcak = huruf[indexAcak];
    hurufAcak = Math.random() < 0.5 ? hurufAcak.toUpperCase() : hurufAcak;
    hasil += hurufAcak;
  }
  return hasil;
}