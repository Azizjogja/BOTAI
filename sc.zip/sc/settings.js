const fs = require('fs');
const chalk = require('chalk');
const { version } = require("./package.json")

// Settings Bot //
global.owner = '6283838681020'
global.versi = version
global.namaOwner = 'Rexxy'
global.packname = 'Rexxy'
global.botname = 'changli'
global.botname2 = 'changli'

//Settings Link//
global.linkOwner = "https://wa.me/6288239938813"
global.linkGrup = "https://chat.whatsapp.com/EZ54nOxn6pfZ2s3"

// Settings Jeda //
global.delayJpm = 3500
global.delayPushkontak = 3500

//SETING ORDER KUOTA//
global.merchantIdOrderKuota = ""
global.apiOrderKuota = ""
global.qrisOrderKuota = ""


//apikey digital ocean//
global.apiDigitalOcean = "-"
global.apiSimpleBot = "apikey1"

//Settings Saluran //
global.linkSaluran = "https://whatsapp.com/channel/0029Vb7AKUsElaO3Q"
global.idSaluran = "1203634256387@newsletter"
global.namaSaluran = "SALURAN"

//Settings Payment //
global.dana = "Tidak Tersedia"
global.ovo = "Tidak Tersedia"
global.gopay = "Tidak Tersedia"

// Settings Image //
global.image = {
menu: "https://img1.pixhost.to/images/11744/686756733_image.jpg", 
reply: "https://img1.pixhost.to/images/11745/686761722_image.jpg", 
logo: "https://img1.pixhost.to/images/11744/686756733_image.jpg", 
qris: "https://files.catbox.moe/ypw95p.jpg"
}

// Settings Api Panel//
global.egg = "15" // Egg ID
global.nestid = "5" // nest ID
global.loc = "1" // Location ID
global.domain = "https://apaya.welperoffcial.my.id"
global.apikey = "ptla_TPPycWa79q3Yz6D7ZXrUdg6XVZMiqYj3CuozC8RNm9k" //ptla
global.capikey = "ptlc_OxCnZts5gA47CucixPUWF8geUhbZAF7GQgaL1s3Cce2" //ptlc

//Settings Api Panel 2//
global.eggV2 = "15" // Egg ID
global.nestidV2 = "5" // nest ID
global.locV2 = "1" // Location ID
global.domainV2 = "https://t.com"
global.apikeyV2 = "ptla_lfucQxgxJ2q9YARtJmIBMqE0nbAP0DqgULZV4XyTepP" //ptla
global.capikeyV2 = "ptlc_6HPcjlup1PXA1U7AxMq5dA5s2D612xs7j93Pqd743rK" //ptlc

//Settings Message~//
global.mess = {
	owner: "*[ Akses Ditolak ]*\nFitur ini hanya untuk owner bot!",
	admin: "*[ Akses Ditolak ]*\nFitur ini hanya untuk admin grup!",
	botAdmin: "*[ Akses Ditolak ]*\nFitur ini hanya untuk ketika bot menjadi admin!",
	group: "*[ Akses Ditolak ]*\nFitur ini hanya untuk dalam grup!",
	private: "*[ Akses Ditolak ]*\nFitur ini hanya untuk dalam private chat!",
	prem: "*[ Akses Ditolak ]*\nFitur ini hanya untuk user premium!",
	wait: 'Loading...',
	error: 'Error!',
	done: 'Done'
}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})