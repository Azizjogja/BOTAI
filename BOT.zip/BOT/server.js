import "dotenv/config";
import express from "express";
import fetch from "node-fetch";
import crypto from "crypto";
import path from "path";
import { fileURLToPath } from "url";

const app = express();
app.use(express.json());

// static web UI
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
app.use(express.static(path.join(__dirname, "public")));

const PORT = process.env.PORT || 3000;
const OPENROUTER_API_KEY = process.env.OPENROUTER_API_KEY;
const MODEL = process.env.OPENROUTER_MODEL || "qwen/qwen3-4b:free";

if (!OPENROUTER_API_KEY) {
  throw new Error("Missing OPENROUTER_API_KEY in .env");
}

// memory chat: session_id -> messages[]
const sessions = new Map();

function getSession(sessionId) {
  if (!sessions.has(sessionId)) {
    sessions.set(sessionId, [
      { role: "system", content: "Kamu adalah asisten AI yang ramah, jelas, dan membantu." }
    ]);
  }
  return sessions.get(sessionId);
}

async function callOpenRouter(messages) {
  const res = await fetch("https://openrouter.ai/api/v1/chat/completions", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${OPENROUTER_API_KEY}`,
      "Content-Type": "application/json",
      "HTTP-Referer": "http://localhost",
      "X-Title": "My Own AI Bot"
    },
    body: JSON.stringify({
      model: MODEL,
      messages,
      temperature: 0.7
    })
  });

  if (!res.ok) {
    const txt = await res.text();
    throw new Error(`OpenRouter ${res.status}: ${txt}`);
  }

  const data = await res.json();
  return data?.choices?.[0]?.message?.content ?? "";
}

// bikin session id
app.get("/api/session", (req, res) => {
  const sessionId = crypto.randomBytes(16).toString("hex");
  getSession(sessionId);
  res.json({ sessionId });
});

// chat endpoint
app.post("/api/chat", async (req, res) => {
  try {
    const { sessionId, message } = req.body || {};
    if (!sessionId || !message) return res.status(400).json({ error: "sessionId & message required" });

    const history = getSession(sessionId);
    history.push({ role: "user", content: String(message) });

    const reply = await callOpenRouter(history);
    history.push({ role: "assistant", content: reply });

    res.json({ reply });
  } catch (err) {
    res.status(500).json({ error: String(err.message || err) });
  }
});

// reset chat
app.post("/api/reset", (req, res) => {
  const { sessionId } = req.body || {};
  if (!sessionId) return res.status(400).json({ error: "sessionId required" });

  sessions.delete(sessionId);
  getSession(sessionId);

  res.json({ ok: true });
});

app.listen(PORT, () => {
  console.log(`✅ My AI Bot running: http://localhost:${PORT}`);
});