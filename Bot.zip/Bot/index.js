import 'dotenv/config';
import { Telegraf } from 'telegraf';

const TELEGRAM_BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN;
const DEEPSEEK_API_KEY = process.env.DEEPSEEK_API_KEY;

// DeepSeek OpenAI-compatible endpoint
const DEEPSEEK_BASE_URL = process.env.DEEPSEEK_BASE_URL || 'https://api.deepseek.com';
const MODEL = process.env.DEEPSEEK_MODEL || 'deepseek-chat';

if (!TELEGRAM_BOT_TOKEN) throw new Error('Missing TELEGRAM_BOT_TOKEN in env');
if (!DEEPSEEK_API_KEY) throw new Error('Missing DEEPSEEK_API_KEY in env');

const bot = new Telegraf(TELEGRAM_BOT_TOKEN);

// Simpan konteks per user (memory ringan)
const histories = new Map(); // userId -> [{role, content}, ...]
const MAX_TURNS = 12; // total message objects (user+assistant) yang disimpan

function getHistory(userId) {
  if (!histories.has(userId)) histories.set(userId, []);
  return histories.get(userId);
}

function trimHistory(arr) {
  // sisakan MAX_TURNS terakhir
  if (arr.length > MAX_TURNS) arr.splice(0, arr.length - MAX_TURNS);
}

async function deepseekChat(messages) {
  const url = `${DEEPSEEK_BASE_URL}/chat/completions`;

  const res = await fetch(url, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${DEEPSEEK_API_KEY}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      model: MODEL,
      messages,
      temperature: 0.7,
      max_tokens: 800
    })
  });

  if (!res.ok) {
    const text = await res.text().catch(() => '');
    throw new Error(`DeepSeek API error: ${res.status} ${res.statusText} ${text}`);
  }

  const data = await res.json();
  const content = data?.choices?.[0]?.message?.content;
  if (!content) throw new Error('DeepSeek API returned empty response');
  return content;
}

bot.start(async (ctx) => {
  await ctx.reply(
    "Hai! Aku bot AI pakai DeepSeek.\n\n" +
    "Kirim pesan apa saja untuk dijawab.\n" +
    "Perintah:\n" +
    "/reset - hapus konteks chat\n" +
    "/help - bantuan"
  );
});

bot.command('help', async (ctx) => {
  await ctx.reply(
    "Cara pakai:\n" +
    "- Kirim pesan → aku balas pakai DeepSeek\n" +
    "- /reset → reset konteks\n\n" +
    "Tips: kalau kamu mau mode lebih singkat/panjang, bilang di chat."
  );
});

bot.command('reset', async (ctx) => {
  const userId = ctx.from?.id;
  if (userId) histories.set(userId, []);
  await ctx.reply('Konteks chat sudah di-reset ✅');
});

bot.on('text', async (ctx) => {
  const userId = ctx.from?.id;
  if (!userId) return;

  const userText = ctx.message.text?.trim();
  if (!userText) return;

  const history = getHistory(userId);

  const system = {
    role: 'system',
    content: 'Kamu asisten yang helpful. Jawab dalam Bahasa Indonesia, ringkas tapi jelas.'
  };

  const messages = [system, ...history, { role: 'user', content: userText }];

  try {
    await ctx.sendChatAction('typing');
    const answer = await deepseekChat(messages);

    // simpan konteks
    history.push({ role: 'user', content: userText });
    history.push({ role: 'assistant', content: answer });
    trimHistory(history);

    await ctx.reply(answer);
  } catch (err) {
    await ctx.reply(`Error: ${err.message}`);
  }
});

bot.catch((err) => {
  console.error('Bot error:', err);
});

bot.launch().then(() => {
  console.log('✅ Bot is running (polling)...');
});

// Graceful stop untuk VPS/systemd/docker
process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));